# Welcome to My Reactjs Calculator
By Dilshod Alimbekov 2004.12.31
## Task
Create a ReactJS Application.
It will be a single route application.
You will be able to perform all simple operation: */+-
## Description
I used a hook that useState
methods: concat, slice, 
easy to understanding my function
## Installation
When you create react app, node modules automatically install
## Usage
for code work need write npm start in terminal

```
./my_project argument1 argument2
```

### The Core Team
<a href='https://github.com/dilshodalimbekov04'>MyCalculator </a>

<span><i>Made at <a href='https://qwasar.io'>Qwasar Silicon Valley</a></i></span>
<span><img alt='Qwasar Silicon Valley Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px'></span>
